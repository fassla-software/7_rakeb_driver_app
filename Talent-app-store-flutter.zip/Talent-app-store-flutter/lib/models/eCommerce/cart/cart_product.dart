import 'package:talent_store/models/eCommerce/cart/gift.dart';
import 'package:talent_store/models/eCommerce/cart/product_option.dart';

class CartItem {
  CartItem({
    required this.shopId,
    required this.shopName,
    required this.shopLogo,
    required this.shopRating,
    required this.cartProduct,
  });
  late final int shopId;
  late final String shopName;
  late final String shopLogo;
  late final String shopRating;
  late final bool hasGift;
  late final List<CartProduct> cartProduct;

  CartItem.fromJson(Map<String, dynamic> json) {
    shopId = json['shop_id'];
    shopName = json['shop_name'];
    shopLogo = json['shop_logo'];
    shopRating = json['shop_rating'].toString();
    hasGift = json['has_gift'] ?? false;
    cartProduct = (json['products'] as List<dynamic>)
        .map((product) => CartProduct.fromJson(product))
        .toList();
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['shop_id'] = shopId;
    data['shop_name'] = shopName;
    data['shop_logo'] = shopLogo;
    data['shop_rating'] = shopRating;
    data['has_gift'] = hasGift;
    data['products'] = cartProduct.map((product) => product.toJson()).toList();
    return data;
  }
}

class CartProduct {
  late final int id;
  late final int quantity;
  late final String name;
  late final String thumbnail;
  late final String? brand;
  late final double price;
  late final double discountPrice;
  late final double discountPercentage;
  late final double rating;
  late final String totalReviews;
  late final String totalSold;
  late final ProductOption? color;
  late final ProductOption? size;
  late final String? unit;
  late final Gift? gift;

  CartProduct({
    required this.id,
    required this.quantity,
    required this.name,
    required this.thumbnail,
    this.brand,
    required this.price,
    required this.discountPrice,
    required this.discountPercentage,
    required this.rating,
    required this.totalReviews,
    required this.totalSold,
    this.color,
    this.size,
    this.unit,
    this.gift,
  });

  CartProduct.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    quantity = json['quantity'];
    name = json['name'];
    thumbnail = json['thumbnail'];
    brand = json['brand'];
    price = (json['price'] as num).toDouble();
    discountPrice = (json['discount_price'] as num).toDouble();
    discountPercentage =
        (json['discount_percentage'] as num).toDouble();
    rating = (json['rating'] as num).toDouble();
    totalReviews = json['total_reviews'].toString();
    totalSold = json['total_sold'].toString();

    color = json['color'] != null
        ? ProductOption.fromJson(json['color'])
        : null;

    size = json['size'] != null
        ? ProductOption.fromJson(json['size'])
        : null;

    unit = json['unit'];
    gift = json['gift'] != null ? Gift.fromMap(json['gift']) : null;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'quantity': quantity,
        'name': name,
        'thumbnail': thumbnail,
        'brand': brand,
        'price': price,
        'discount_price': discountPrice,
        'discount_percentage': discountPercentage,
        'rating': rating,
        'total_reviews': totalReviews,
        'total_sold': totalSold,
        'color': color?.toJson(),
        'size': size?.toJson(),
        'unit': unit,
        'gift': gift?.toJson(),
      };
}

