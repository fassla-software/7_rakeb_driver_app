import 'dart:convert';

class AddToCartModel {
  final int productId;
  final int quantity;
  final int? sizeId;
  final int? colorId;
  final int? unitId;

  AddToCartModel({
    required this.productId,
    required this.quantity,
    this.sizeId,
    this.colorId,
    this.unitId,
  });

  AddToCartModel copyWith({
    int? productId,
    int? quantity,
    int? sizeId,
    int? colorId,
    int? unitId,
  }) {
    return AddToCartModel(
      productId: productId ?? this.productId,
      quantity: quantity ?? this.quantity,
      sizeId: sizeId ?? this.sizeId,
      colorId: colorId ?? this.colorId,
      unitId: unitId ?? this.unitId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'product_id': productId,
      'quantity': quantity,
      if (sizeId != null) 'size': sizeId,
      if (colorId != null) 'color': colorId,
      if (unitId != null) 'unit': unitId,
    };
  }

  factory AddToCartModel.fromMap(Map<String, dynamic> map) {
    return AddToCartModel(
      productId: map['product_id'] as int,
      quantity: map['quantity'] as int,
      sizeId: map['size'],
      colorId: map['color'],
      unitId: map['unit'],
    );
  }

  String toJson() => json.encode(toMap());

  factory AddToCartModel.fromJson(String source) =>
      AddToCartModel.fromMap(json.decode(source));
}

