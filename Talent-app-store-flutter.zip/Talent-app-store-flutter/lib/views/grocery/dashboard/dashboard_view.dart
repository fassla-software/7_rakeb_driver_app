import 'package:flutter/material.dart';
import 'package:talent_store/views/pharmacy/dashboard/layouts/dashboar_layout.dart';

class GroceryDashboardView extends StatelessWidget {
  const GroceryDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return const GroceryDashboardLayout();
  }
}
