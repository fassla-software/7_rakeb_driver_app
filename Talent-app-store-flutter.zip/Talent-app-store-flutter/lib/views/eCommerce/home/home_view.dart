import 'package:flutter/material.dart';
import 'package:talent_store/views/eCommerce/home/layouts/home_view_layout.dart';

class EcommerceHomeView extends StatelessWidget {
  const EcommerceHomeView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const EcommerceHomeViewLayout();
  }
}
