// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:talent_store/views/eCommerce/shops/layouts/shops_layout.dart';

class EcommerceShopsView extends StatelessWidget {
  const EcommerceShopsView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const EcommerceShopsLayout();
  }
}
