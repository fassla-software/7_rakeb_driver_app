import 'package:flutter/material.dart';
import 'package:talent_store/views/eCommerce/favourites/layouts/favourites_products_layout.dart';

class FavouritesProductsView extends StatelessWidget {
  const FavouritesProductsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const FavouritesProductsLayout();
  }
}
