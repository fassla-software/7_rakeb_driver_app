import 'package:flutter/material.dart';
import 'package:talent_store/views/food/dashboard/layouts/dashboar_layout.dart';

class FoodDashboardView extends StatelessWidget {
  const FoodDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return const FoodDashboardLayout();
  }
}
