import 'package:flutter/material.dart';
import 'package:talent_store/views/pharmacy/dashboard/layouts/dashboar_layout.dart';

class PharmacyDashboardView extends StatelessWidget {
  const PharmacyDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return const GroceryDashboardLayout();
  }
}
