import 'package:flutter/material.dart';
import 'package:talent_store/views/common/authentication/layouts/login_layout.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return const LoginLayout();
  }
}
