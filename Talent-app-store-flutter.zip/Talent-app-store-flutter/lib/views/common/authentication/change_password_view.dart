import 'package:flutter/material.dart';
import 'package:talent_store/views/common/authentication/layouts/change_password_layout.dart';

class ChangePasswordView extends StatelessWidget {
  const ChangePasswordView({super.key});

  @override
  Widget build(BuildContext context) {
    return const ChangePasswordLayout();
  }
}
