import 'package:flutter/material.dart';
import 'package:talent_store/views/common/language/layouts/language_layout.dart';

class LanguageView extends StatelessWidget {
  const LanguageView({super.key});

  @override
  Widget build(BuildContext context) {
    return const LanguageLayout();
  }
}
