import 'package:flutter/material.dart';
import 'package:talent_store/views/common/support/layouts/support_layout.dart';

class SupportView extends StatelessWidget {
  const SupportView({super.key});

  @override
  Widget build(BuildContext context) {
    return const SupportLayout();
  }
}
