import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:talent_store/config/app_constants.dart';
import 'package:talent_store/models/eCommerce/common/size_model.dart';
import 'package:talent_store/utils/api_client.dart';

class SizeService {
  final Ref ref;
  
  SizeService(this.ref);

  Future<List<SizeModel>> getSizes() async {
    try {
      final response = await ref.read(apiClientProvider).get(
        AppConstants.getSizes,
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = response.data['data'] ?? [];
        
        return data.map((json) => SizeModel.fromJson(json as Map<String, dynamic>)).toList();
      } else {
        throw Exception('Failed to load sizes: ${response.statusCode}');
      }
    } on DioException catch (e) {
      print('DioException in getSizes: ${e.message}');
      print('Response: ${e.response?.data}');
      rethrow;
    } catch (e) {
      print('Error in getSizes: $e');
      rethrow;
    }
  }
}

final sizeServiceProvider = Provider((ref) => SizeService(ref));

final sizesProvider = FutureProvider<List<SizeModel>>((ref) async {
  return await ref.read(sizeServiceProvider).getSizes();
});