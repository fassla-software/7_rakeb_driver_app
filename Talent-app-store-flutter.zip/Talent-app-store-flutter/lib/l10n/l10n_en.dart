// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'l10n.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class SEn extends S {
  SEn([String locale = 'en']) : super(locale);

  @override
  String get aboutProduct => 'About Product';

  @override
  String get addNew => 'Add New';

  @override
  String get addNewAddress => 'Add New Address';

  @override
  String get addressLine1 => 'Address Line 1';

  @override
  String get addressLine2 => 'Address Line 2';

  @override
  String get addressTag => 'Address Tag';

  @override
  String get addToCart => 'Add To Cart';

  @override
  String get all => 'All';

  @override
  String get allCategories => 'All Categories';

  @override
  String get alreadyHaveAnAccount => 'Already have an account?';

  @override
  String get alwaysWithYourReach => 'Always within your reach';

  @override
  String get amount => 'Amount';

  @override
  String get applied => 'Applied';

  @override
  String get apply => 'Apply';

  @override
  String get area => 'Area';

  @override
  String get areYouSureWantToCancelOrder =>
      'Are you sure want to cancel this order?';

  @override
  String get areYouWantOrderAgain => 'Are you sure want to order again?';

  @override
  String get buyNow => 'Buy Now';

  @override
  String get cancel => 'Cancel';

  @override
  String get cancelled => 'Cancelled';

  @override
  String get cancelOrder => 'Cancel Order';

  @override
  String get cashOnDelivery => 'Cash on Delivery';

  @override
  String get cashPaymentDes => 'Are you sure want to order now with cash?';

  @override
  String get categories => 'Categories';

  @override
  String get change => 'Change';

  @override
  String get changePassowrd => 'Change Password';

  @override
  String get changePassword => 'Change Password';

  @override
  String get checkInternetConnection => 'Check Internet Connection';

  @override
  String get checkout => 'Checkout';

  @override
  String get clear => 'Clear';

  @override
  String get close => 'Close';

  @override
  String get collect => 'Collect';

  @override
  String get collected => 'Collected';

  @override
  String get color => 'Color';

  @override
  String get confirm => 'Confirm';

  @override
  String get confirmNewPass => 'Confirm new password';

  @override
  String get confirmOtp => 'Confirm OTP';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get contactVia => 'or,Contact via';

  @override
  String get continueShopping => 'Continue Shopping';

  @override
  String get couponApplyValidation =>
      'Please select Shop to apply the promo code!';

  @override
  String get createNewPass => 'Create new password';

  @override
  String get createNewPassword => 'Create New Password';

  @override
  String get creditOrDebitCard => 'Credit or Debit Card';

  @override
  String get currentPassword => 'Current Password';

  @override
  String get customerReview => 'Customer Review';

  @override
  String get date => 'Date';

  @override
  String get dealOfTheDay => 'Deal of the Day';

  @override
  String get defaultAddress => 'Default Address';

  @override
  String get deleteAccount => 'Delete Account';

  @override
  String get deleteAccountDes =>
      'Are you sure you want to delete your account? This action cannot be undone.';

  @override
  String get deleteThis => 'Delete this';

  @override
  String get delivered => 'Delivered';

  @override
  String get deliverTo => 'Deliver to';

  @override
  String get deliveryAddress => 'Delivery Address';

  @override
  String get deliveryCharge => 'Delivery Charge';

  @override
  String get discount => 'Discount';

  @override
  String get dontHaveAccount => 'Don\'t have an account?';

  @override
  String get downloadInvoice => 'Download Invoice';

  @override
  String get edit => 'Edit';

  @override
  String get email => 'Email';

  @override
  String get emailOrPhone => 'Email or Phone';

  @override
  String get endingIn => 'Ending in';

  @override
  String get enFullName => 'Enter full name';

  @override
  String get enterCurrentPass => 'Enter current password';

  @override
  String get enterotp => 'Enter OTP';

  @override
  String get enterPhoneNum => 'Enter your phone number';

  @override
  String get enterPhoneNumber => 'Enter phone number';

  @override
  String get estdTime => 'Estimated delivery time';

  @override
  String get favorites => 'Favourites ';

  @override
  String get filter => 'Filter';

  @override
  String get flat => 'Flat';

  @override
  String get forgotPassword => 'Forgot Password';

  @override
  String get fullName => 'Full Name';

  @override
  String get getInTouch => 'Get in Touch';

  @override
  String get guest => 'Guest User';

  @override
  String get home => 'Home';

  @override
  String get hWtheProduct => 'How was the product?';

  @override
  String get isRequired => 'is required!';

  @override
  String get justForYou => 'Just For You';

  @override
  String get language => 'Language';

  @override
  String get login => 'Log in';

  @override
  String get logout => 'Log out';

  @override
  String get logoutDialogDes =>
      'You will need to re-enter your credentials to access your account again.Your local save data will be clean!';

  @override
  String get logoutDialogTitle => 'Are you sure want to logout?';

  @override
  String get makeItDefault => 'Make it default address';

  @override
  String get manageAddress => 'Manage Address';

  @override
  String get message => 'Message';

  @override
  String get minimumSpend => 'Minimum spend';

  @override
  String get more => 'profile';

  @override
  String get mostSelling => 'Most Selling';

  @override
  String get myCart => 'My Cart';

  @override
  String get myOrder => 'My Order';

  @override
  String get myProfile => 'My Profile';

  @override
  String get name => 'Name';

  @override
  String get newPassword => 'New Password';

  @override
  String get newProduct => 'New Product';

  @override
  String get no => 'No';

  @override
  String get noInternetDes =>
      'No Internet connection was found. Check your connection or try again.';

  @override
  String get office => 'Office';

  @override
  String get onTheWay => 'On The Way';

  @override
  String get orderAgain => 'Order Again';

  @override
  String get orderCancelDialogDes => 'Are you sure want to cancel this order?';

  @override
  String get orderDate => 'Order Date';

  @override
  String get orderDetails => 'Order Details';

  @override
  String get orderId => 'Order ID';

  @override
  String get orderNow => 'Order Now';

  @override
  String get orderPlaceDes =>
      'You will receive an order confirmation\nemail with details of your order';

  @override
  String get orders => 'Orders';

  @override
  String get orderStatus => 'Order Status';

  @override
  String get orderSummary => 'Order Summary';

  @override
  String get other => 'Other';

  @override
  String get password => 'Password';

  @override
  String get payableAmount => 'Payable Amount';

  @override
  String get paymentFailed => 'Payment Failed';

  @override
  String get paymentFailedDes =>
      'Sorry, we couldn\'t process your payment. Please try again later.';

  @override
  String get paymentMethod => 'Payment Method';

  @override
  String get paymentSuccess => 'Payment Success';

  @override
  String get paymentSuccessDes =>
      'Your payment has been successfully processed.';

  @override
  String get payNow => 'Pay Now';

  @override
  String get pending => 'Pending';

  @override
  String get phone => 'Phone';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get placeOrder => 'Place Order';

  @override
  String get popularProducts => 'Popular Products';

  @override
  String get postalCode => 'Postal Code';

  @override
  String get priceHighToLow => 'Price:High To Low';

  @override
  String get priceLowToHigh => 'Price: Low To High';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get processig => 'Processing';

  @override
  String get productInCart => 'This product is already in your cart!';

  @override
  String get productNotFount => 'Product Not Found!';

  @override
  String get productPrice => 'Product Price';

  @override
  String get promoCode => 'Enter promo code here';

  @override
  String get pyment => 'Payment';

  @override
  String get readLess => 'Read Less';

  @override
  String get readMore => 'Read More';

  @override
  String get recoverPassDes =>
      'Enter the phone number that you used when register to recover your password. You will receive a OTP code.';

  @override
  String get recoverPassword => 'Recover Password';

  @override
  String get refundPolicy => 'Refund Policy';

  @override
  String get resend => 'Resend';

  @override
  String get resendCode => 'Resend Code in';

  @override
  String get review => 'Review';

  @override
  String get save => 'Save';

  @override
  String get savedAddress => 'Saved Address';

  @override
  String get searchCountryName => 'Search country name';

  @override
  String get searchProduct => 'Search your product here!';

  @override
  String get select => 'Select';

  @override
  String get send => 'Send';

  @override
  String get sendOtp => 'Send OTP';

  @override
  String get serviceItem => 'Service Item';

  @override
  String get setPassword => 'Set Password';

  @override
  String get shoppingFrom => 'Shopping From';

  @override
  String get shops => 'Shops';

  @override
  String get shopSelectValidation =>
      'Please select shop for confirm the checkout!';

  @override
  String get signUp => 'Sign Up';

  @override
  String get signUpToContinue => 'Please sign up to continue shopping';

  @override
  String get similarProducts => 'Similar Products';

  @override
  String get size => 'Size';

  @override
  String get skip => 'Skip';

  @override
  String get sortBy => 'Sort by';

  @override
  String get startWriting => 'Start writing...';

  @override
  String get status => 'Status';

  @override
  String get storeVoucher => 'Store voucher';

  @override
  String get subject => 'Subject';

  @override
  String get submit => 'Submit';

  @override
  String get subTotal => 'Sub Total';

  @override
  String get support => 'Support';

  @override
  String get termsCondistions => 'Terms & Conditions';

  @override
  String get themeMode => 'Theme Mode';

  @override
  String get toBePaid => 'To Be Paid';

  @override
  String get topSeller => 'Top Seller';

  @override
  String get totalAmount => 'Total Amount';

  @override
  String get totalTaxes => 'Total Taxes';

  @override
  String get typeConfirmSecretPassword =>
      'Type and confirm a secret new password for your account.';

  @override
  String get updatePassword => 'Update Password';

  @override
  String get updateProfile => 'Update Profile';

  @override
  String get validity => 'Validity till';

  @override
  String get viewMore => 'View More';

  @override
  String get vistiStore => 'Visit Store';

  @override
  String get voucherFrom => 'Voucher from:';

  @override
  String get voucherNotAvailable => 'No vouchers found for this store!';

  @override
  String get welcomeBack => 'Welcome Back!';

  @override
  String get weSentOtp => 'We sent OTP code to your phone number';

  @override
  String get whoops => 'Whoops!!';

  @override
  String get wishlist => 'Wishlist';

  @override
  String get writeSATP => 'Write something about this product';

  @override
  String get writeSubjectHere => 'Write subject here';

  @override
  String get yes => 'Yes';

  @override
  String get youAreNotLoggedIn => 'You are unauthorized please login first!';

  @override
  String get yourCartIsEmpty => 'Your cart is empty!';

  @override
  String get yourOrderHasBeenPlaced => 'Your order has been\n placed!';
}
