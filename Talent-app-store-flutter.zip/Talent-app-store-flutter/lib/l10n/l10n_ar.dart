// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'l10n.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class SAr extends S {
  SAr([String locale = 'ar']) : super(locale);

  @override
  String get aboutProduct => 'حول المنتج';

  @override
  String get addNew => 'اضف جديد';

  @override
  String get addNewAddress => 'أضف عنوانًا جديدًا';

  @override
  String get addressLine1 => 'العنوان سطر 1';

  @override
  String get addressLine2 => 'سطر العنوان 2';

  @override
  String get addressTag => 'علامة العنوان';

  @override
  String get addToCart => 'أضف إلى السلة';

  @override
  String get all => 'الجميع';

  @override
  String get allCategories => 'جميع الفئات';

  @override
  String get alreadyHaveAnAccount => 'هل لديك حساب؟';

  @override
  String get alwaysWithYourReach => 'دائما في متناول يديك';

  @override
  String get amount => 'كمية';

  @override
  String get applied => 'تطبيق';

  @override
  String get apply => 'يتقدم';

  @override
  String get area => 'منطقة';

  @override
  String get areYouSureWantToCancelOrder =>
      'هل أنت متاكد من أنك تريد ألغاء هذا الطلب؟';

  @override
  String get areYouWantOrderAgain => 'هل أنت متاكد من أنك تريد الطلب مرة أخرى؟';

  @override
  String get buyNow => 'اشتري الآن';

  @override
  String get cancel => 'يلغي';

  @override
  String get cancelled => 'ألغيت';

  @override
  String get cancelOrder => 'الغاء الطلب';

  @override
  String get cashOnDelivery => 'الدفع عند التسليم';

  @override
  String get cashPaymentDes => 'هل أنت متأكد من أنك تريد الطلب الآن نقدًا؟';

  @override
  String get categories => 'فئات';

  @override
  String get change => 'تغيير';

  @override
  String get changePassowrd => 'Change Password';

  @override
  String get changePassword => 'تغيير كلمة المرور';

  @override
  String get checkInternetConnection => 'Check Internet Connection';

  @override
  String get checkout => 'الدفع';

  @override
  String get clear => 'واضح';

  @override
  String get close => 'اغلاق';

  @override
  String get collect => 'يجمع';

  @override
  String get collected => 'تم جمعها';

  @override
  String get color => 'لون';

  @override
  String get confirm => 'يتأكد';

  @override
  String get confirmNewPass => 'تأكيد كلمة المرور الجديدة';

  @override
  String get confirmOtp => 'تأكيد OTP';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get contactVia => 'الاتصال عبر';

  @override
  String get continueShopping => 'مواصلة التسوق';

  @override
  String get couponApplyValidation =>
      'الرجاء تحديد متجر لتطبيق الرمز الترويجي!';

  @override
  String get createNewPass => 'إنشاء كلمة مرور جديدة';

  @override
  String get createNewPassword => 'إنشاء كلمة مرور جديدة';

  @override
  String get creditOrDebitCard => 'ائتمان او بطاقة الخصم';

  @override
  String get currentPassword => 'كلمة السر الحالية';

  @override
  String get customerReview => 'رأي العميل';

  @override
  String get date => 'تاريخ';

  @override
  String get dealOfTheDay => 'صفقة اليوم';

  @override
  String get defaultAddress => 'العنوان الافتراضي';

  @override
  String get deleteAccount => 'حذف الحساب';

  @override
  String get deleteAccountDes =>
      'هل أنت متاكد من أنك تريد حذف حسابك؟ هذا الأكشن لا يمكن التراجع عنه.';

  @override
  String get deleteThis => 'امسح هذه';

  @override
  String get delivered => 'تم التوصيل';

  @override
  String get deliverTo => 'يسلم إلى';

  @override
  String get deliveryAddress => 'عنوان التسليم';

  @override
  String get deliveryCharge => 'رسوم التوصيل';

  @override
  String get discount => 'تخفيض';

  @override
  String get dontHaveAccount => 'ليس لديك حساب؟';

  @override
  String get downloadInvoice => 'تحميل فاتورة';

  @override
  String get edit => 'يحرر';

  @override
  String get email => 'بريد إلكتروني';

  @override
  String get emailOrPhone => 'البريد الالكتروني او الهاتف';

  @override
  String get endingIn => 'تنتهي في';

  @override
  String get enFullName => 'أدخل الاسم الكامل';

  @override
  String get enterCurrentPass => 'إدخل كلمة السر الحالية';

  @override
  String get enterotp => 'أدخل OTP';

  @override
  String get enterPhoneNum => 'أدخل رقم هاتفك';

  @override
  String get enterPhoneNumber => 'أدخل رقم الهاتف';

  @override
  String get estdTime => 'يقدر وقت التسليم';

  @override
  String get favorites => 'المفضلة';

  @override
  String get filter => 'منقي';

  @override
  String get flat => 'مستوي';

  @override
  String get forgotPassword => 'هل نسيت كلمة السر';

  @override
  String get fullName => 'الاسم الكامل';

  @override
  String get getInTouch => 'ابقى على تواصل';

  @override
  String get guest => 'حساب زائر';

  @override
  String get home => 'الرئسيه';

  @override
  String get hWtheProduct => 'كيف كان المنتج؟';

  @override
  String get isRequired => 'مطلوب!';

  @override
  String get justForYou => 'فقط لك';

  @override
  String get language => 'لغة';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get logout => 'تسجيل خروج';

  @override
  String get logoutDialogDes =>
      'ستحتاج إلى إعادة إدخال بيانات الاعتماد الخاصة بك للوصول إلى حسابك مرة أخرى. ستكون بيانات حفظك المحلية نظيفة!';

  @override
  String get logoutDialogTitle => 'هل أنت متأكد من تريد تسجيل الدخول؟';

  @override
  String get makeItDefault => 'اجعله العنوان الافتراضي';

  @override
  String get manageAddress => 'إدارة العنوان';

  @override
  String get message => 'رسالة';

  @override
  String get minimumSpend => 'الحد الأدنى للإنفاق';

  @override
  String get more => 'الحساب الشخصى';

  @override
  String get mostSelling => 'معظم البيع';

  @override
  String get myCart => 'عربتي';

  @override
  String get myOrder => 'طلبي';

  @override
  String get myProfile => 'ملفي';

  @override
  String get name => 'اسم';

  @override
  String get newPassword => 'كلمة المرور الجديدة';

  @override
  String get newProduct => 'منتج جديد';

  @override
  String get no => 'لا';

  @override
  String get noInternetDes =>
      'No Internet connection was found. Check your connection or try again.';

  @override
  String get office => 'مكتب';

  @override
  String get onTheWay => 'علي الطريق';

  @override
  String get orderAgain => 'أجل مرة أخرى';

  @override
  String get orderCancelDialogDes => 'هل أنت متأكد أنك تريد إلغاء هذا الطلب؟';

  @override
  String get orderDate => 'تاريخ الطلب';

  @override
  String get orderDetails => 'تفاصيل الطلب';

  @override
  String get orderId => 'رقم التعريف الخاص بالطلب';

  @override
  String get orderNow => 'طلب الان';

  @override
  String get orderPlaceDes =>
      'سوف تتلقى رسالة تأكيد الطلب/البريد الإلكتروني مع تفاصيل طلبك';

  @override
  String get orders => 'طلبات';

  @override
  String get orderStatus => 'حالة الطلب';

  @override
  String get orderSummary => 'ملخص الطلب';

  @override
  String get other => 'آخر';

  @override
  String get password => 'كلمة المرور';

  @override
  String get payableAmount => 'مبلغ مستحق الدفع';

  @override
  String get paymentFailed => 'فشل الدفع';

  @override
  String get paymentFailedDes =>
      'عفوا، لم يتم تجهيز الدفع. الرجاء المحاولة مرة أخرى في وقت لاحق.';

  @override
  String get paymentMethod => 'طريقة الدفع او السداد';

  @override
  String get paymentSuccess => 'نجاح الدفع';

  @override
  String get paymentSuccessDes => 'تمت عملية الدفع بنجاح.';

  @override
  String get payNow => 'ادفع الان';

  @override
  String get pending => 'قيد الانتظار';

  @override
  String get phone => 'هاتف';

  @override
  String get phoneNumber => 'رقم التليفون';

  @override
  String get placeOrder => 'تقديم الطلب';

  @override
  String get popularProducts => 'المنتجات الشعبية';

  @override
  String get postalCode => 'رمز بريدي';

  @override
  String get priceHighToLow => 'السعر الاعلى الى الادنى';

  @override
  String get priceLowToHigh => 'السعر من الارخص للاعلى';

  @override
  String get privacyPolicy => 'سياسة الخصوصية';

  @override
  String get processig => 'يعالج';

  @override
  String get productInCart => 'هذا المنتج بالفعل في عربة التسوق الخاصة بك!';

  @override
  String get productNotFount => 'الصنف غير موجود!';

  @override
  String get productPrice => 'سعر المنتج';

  @override
  String get promoCode => 'أدخل الرمز الترويجي هنا';

  @override
  String get pyment => 'الدفع';

  @override
  String get readLess => 'أقرأ أقل';

  @override
  String get readMore => 'اقرأ أكثر';

  @override
  String get recoverPassDes =>
      'أدخل رقم الهاتف الذي استخدمته عند التسجيل لاستعادة كلمة المرور الخاصة بك. سوف تتلقى رمز OTP.';

  @override
  String get recoverPassword => 'إستعادة كلمة المرور';

  @override
  String get refundPolicy => 'سياسة الاسترجاع';

  @override
  String get resend => 'إعادة إرسال';

  @override
  String get resendCode => 'إعادة تقديم رمز في';

  @override
  String get review => 'مراجعة';

  @override
  String get save => 'يحفظ';

  @override
  String get savedAddress => 'العنوان المحفوظ';

  @override
  String get searchCountryName => 'البحث عن اسم البلد';

  @override
  String get searchProduct => 'ابحث في منتجك هنا!';

  @override
  String get select => 'حدد';

  @override
  String get send => 'يرسل';

  @override
  String get sendOtp => 'إرسال OTP';

  @override
  String get serviceItem => 'عنصر الخدمة';

  @override
  String get setPassword => 'ضبط كلمة السر';

  @override
  String get shoppingFrom => 'التسوق من';

  @override
  String get shops => 'محلات';

  @override
  String get shopSelectValidation => 'الرجاء تحديد متجر لتأكيد الخروج!';

  @override
  String get signUp => 'اشتراك';

  @override
  String get signUpToContinue => 'يرجى الاشتراك لمواصلة التسوق';

  @override
  String get similarProducts => 'منتجات مماثلة';

  @override
  String get size => 'مقاس';

  @override
  String get skip => 'تخطي';

  @override
  String get sortBy => 'ترتيب حسب';

  @override
  String get startWriting => 'ابدأ في الكتابة ...';

  @override
  String get status => 'حالة';

  @override
  String get storeVoucher => 'قسيمة المتجر';

  @override
  String get subject => 'موضوع';

  @override
  String get submit => 'تأكيد';

  @override
  String get subTotal => 'مجموع';

  @override
  String get support => 'الدعم';

  @override
  String get termsCondistions => 'البنود و الظروف';

  @override
  String get themeMode => 'المظهر';

  @override
  String get toBePaid => 'لكي تدفع';

  @override
  String get topSeller => 'أعلى بائع';

  @override
  String get totalAmount => 'المبلغ الإجمالي';

  @override
  String get totalTaxes => 'إجمالي الضرائب';

  @override
  String get typeConfirmSecretPassword =>
      'اكتب وتأكيد كلمة مرور جديدة سرية لحسابك.';

  @override
  String get updatePassword => 'تطوير كلمة السر';

  @override
  String get updateProfile => 'تحديث الملف';

  @override
  String get validity => 'الصلاحية حتى';

  @override
  String get viewMore => 'عرض المزيد';

  @override
  String get vistiStore => 'قم بزيارة المعرض او المتجر';

  @override
  String get voucherFrom => 'قسيمة من:';

  @override
  String get voucherNotAvailable => 'لم يتم العثور على قسائم لهذا المتجر!';

  @override
  String get welcomeBack => 'مرحبًا بعودتك!';

  @override
  String get weSentOtp => 'أرسلنا رمز OTP إلى رقم هاتفك';

  @override
  String get whoops => 'Whoops!!';

  @override
  String get wishlist => 'قائمة الرغبات';

  @override
  String get writeSATP => 'اكتب شيئًا عن هذا المنتج';

  @override
  String get writeSubjectHere => 'اكتب الموضوع هنا';

  @override
  String get yes => 'نعم';

  @override
  String get youAreNotLoggedIn =>
      'ليس لديك حساب مسجل. يرجى تسجيل الدخول لأولا!';

  @override
  String get yourCartIsEmpty => 'عربة التسوق فارغة!';

  @override
  String get yourOrderHasBeenPlaced => 'لقد تم تقديم طلبك!';
}
