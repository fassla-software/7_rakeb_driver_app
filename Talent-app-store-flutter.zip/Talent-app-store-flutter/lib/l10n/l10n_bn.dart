// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'l10n.dart';

// ignore_for_file: type=lint

/// The translations for Bengali Bangla (`bn`).
class SBn extends S {
  SBn([String locale = 'bn']) : super(locale);

  @override
  String get aboutProduct => 'পণ্য সম্পর্কে';

  @override
  String get addNew => 'নতুন যোগ করুন';

  @override
  String get addNewAddress => 'নতুন ঠিকানা যোগ করুন';

  @override
  String get addressLine1 => 'ঠিকানা লাইন 1';

  @override
  String get addressLine2 => 'ঠিকানা লাইন ২';

  @override
  String get addressTag => 'ঠিকানা ট্যাগ';

  @override
  String get addToCart => 'কার্টে যোগ করুন';

  @override
  String get all => 'সব';

  @override
  String get allCategories => 'সব ধরনের';

  @override
  String get alreadyHaveAnAccount => 'ইতিমধ্যে একটি একাউন্ট আছে?';

  @override
  String get alwaysWithYourReach => 'সবসময় আপনার নাগালের মধ্যে';

  @override
  String get amount => 'পরিমাণ';

  @override
  String get applied => 'প্রয়োগ করা হয়েছে';

  @override
  String get apply => 'অ্যাপ্লাই';

  @override
  String get area => 'অঞ্চল';

  @override
  String get areYouSureWantToCancelOrder =>
      'আপনি কি আমাদের অর্ডার বাতিল করতে চান?';

  @override
  String get areYouWantOrderAgain => 'আপনি কি আমাদের পুনরায় অর্ডার করতে চান?';

  @override
  String get buyNow => 'এখন কিনুন';

  @override
  String get cancel => 'বাতিল';

  @override
  String get cancelled => 'বাতিল';

  @override
  String get cancelOrder => 'আদেশ বাতিল';

  @override
  String get cashOnDelivery => 'ডেলিভারী কাজ করুন';

  @override
  String get cashPaymentDes => 'আপনি কি নিশ্চিত এখন নগদ দিয়ে অর্ডার করতে চান?';

  @override
  String get categories => 'ক্যাটাগরি';

  @override
  String get change => 'পরিবর্তন করুন';

  @override
  String get changePassowrd => 'পাসওয়ার্ড পরিবর্তন করুন';

  @override
  String get changePassword => 'পাসওয়ার্ড পরিবর্তন করুন';

  @override
  String get checkInternetConnection => 'ইন্টারনেট সংযোগ পরীক্ষা করুন';

  @override
  String get checkout => 'চেকআউট';

  @override
  String get clear => 'পরিষ্কার';

  @override
  String get close => 'বন্ধ';

  @override
  String get collect => 'সংগ্রহ করুন';

  @override
  String get collected => 'সংগৃহীত';

  @override
  String get color => 'আপনার রঙ পছন্দ করুন';

  @override
  String get confirm => 'নিশ্চিত করুন';

  @override
  String get confirmNewPass => 'নিশ্চিত কর নতুন গোপননম্বর';

  @override
  String get confirmOtp => 'OTP নিশ্চিত করুন';

  @override
  String get confirmPassword => 'পাসওয়ার্ড নিশ্চিত করুন';

  @override
  String get contactVia => 'যোগাযোগ করুন';

  @override
  String get continueShopping => 'কেনাকাটা চালিয়ে যান';

  @override
  String get couponApplyValidation =>
      'প্রচার কোড প্রয়োগ করতে অনুগ্রহ করে দোকান নির্বাচন করুন!';

  @override
  String get createNewPass => 'নতুন পাসওয়ার্ড তৈরি করুন';

  @override
  String get createNewPassword => 'নতুন পাসওয়ার্ড তৈরি করুন';

  @override
  String get creditOrDebitCard => 'ক্রেডিট করা বা ডেবিট করা';

  @override
  String get currentPassword => 'বর্তমান পাসওয়ার্ড';

  @override
  String get customerReview => 'গ্রাহক পর্যালোচনা';

  @override
  String get date => 'তারিখ';

  @override
  String get dealOfTheDay => 'আজকের জন্য ডিল';

  @override
  String get defaultAddress => 'ডিফল্ট ঠিকানা';

  @override
  String get deleteAccount => 'অ্যাকাউন্ট মুছে ফেলুন';

  @override
  String get deleteAccountDes =>
      'আপনি আপনার অ্যাকাউন্ট মুছে ফেলতে চান আপনি কি নিশ্চিত? এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।';

  @override
  String get deleteThis => 'এটা মুছে ফেলুন';

  @override
  String get delivered => 'বিতরণ';

  @override
  String get deliverTo => 'ডেলিভারি অ্যাড্রেস ';

  @override
  String get deliveryAddress => 'ডেলিভারী ঠিকানা';

  @override
  String get deliveryCharge => 'ডেলিভারি চার্জ';

  @override
  String get discount => 'ডিসকাউন্ট';

  @override
  String get dontHaveAccount => 'একটি অ্যাকাউন্ট নেই?';

  @override
  String get downloadInvoice => 'চালান ডাউনলোড করুন';

  @override
  String get edit => 'সম্পাদনা';

  @override
  String get email => 'ইমেইল';

  @override
  String get emailOrPhone => 'ইমেইল অথবা ফোন';

  @override
  String get endingIn => 'শেষ হবে';

  @override
  String get enFullName => 'পুরো নাম লিখুন';

  @override
  String get enterCurrentPass => 'বর্তমান পাসওয়ার্ড লিখুন';

  @override
  String get enterotp => 'OTP লিখুন';

  @override
  String get enterPhoneNum => 'আপনার ফোন নম্বর লিখুন';

  @override
  String get enterPhoneNumber => 'ফোন নম্বর লিখুন';

  @override
  String get estdTime => 'আনুমানিক ডেলিভারি সময়';

  @override
  String get favorites => 'প্রিয়';

  @override
  String get filter => 'ফিল্টার';

  @override
  String get flat => 'সমান';

  @override
  String get forgotPassword => 'পাসওয়ার্ড ভুলে গেছেন?';

  @override
  String get fullName => 'পুরো নাম';

  @override
  String get getInTouch => 'যোগাযোগ করুন';

  @override
  String get guest => 'অতিথি ব্যবহারকারী';

  @override
  String get home => 'হোম';

  @override
  String get hWtheProduct => 'পণ্যটি কেমন ছিল?';

  @override
  String get isRequired => 'বাধ্যতামূলক।';

  @override
  String get justForYou => 'আপনার জন্য';

  @override
  String get language => 'ভাষা';

  @override
  String get login => 'প্রবেশ করুন';

  @override
  String get logout => 'লগ আউট';

  @override
  String get logoutDialogDes =>
      'আপনার অ্যাকাউন্টে আবার অ্যাক্সেস করার জন্য আপনাকে আপনার শংসাপত্রগুলি পুনরায় প্রবেশ করতে হবে৷ আপনার স্থানীয় সংরক্ষণ ডেটা পরিষ্কার হবে!';

  @override
  String get logoutDialogTitle => 'আপনি কি নিশ্চিত আপনি লগ আউট করতে চান?';

  @override
  String get makeItDefault => 'এটি ডিফল্ট ঠিকানা করুন';

  @override
  String get manageAddress => 'ঠিকানা পরিচালনা করুন';

  @override
  String get message => 'বার্তা';

  @override
  String get minimumSpend => 'ন্যূনতম ব্যয়';

  @override
  String get more => 'আরও';

  @override
  String get mostSelling => 'সবচেয়ে বেশি বিক্রি হচ্ছে';

  @override
  String get myCart => 'আমার কার্ট';

  @override
  String get myOrder => 'অর্ডার';

  @override
  String get myProfile => 'প্রোফাইল';

  @override
  String get name => 'নাম';

  @override
  String get newPassword => 'নতুন পাসওয়ার্ড';

  @override
  String get newProduct => 'নতুন পণ্য';

  @override
  String get no => 'না';

  @override
  String get noInternetDes =>
      'কোন ইন্টারনেট সংযোগ পাওয়া যায়নি. আপনার সংযোগ পরীক্ষা করুন বা আবার চেষ্টা করুন|';

  @override
  String get office => 'দপ্তর';

  @override
  String get onTheWay => 'পথে';

  @override
  String get orderAgain => 'আবার অর্ডার';

  @override
  String get orderCancelDialogDes =>
      'আপনি কি নিশ্চিত এই অর্ডার বাতিল করতে চান?';

  @override
  String get orderDate => 'অর্ডারের তারিখ';

  @override
  String get orderDetails => 'আদেশ বিবরণী';

  @override
  String get orderId => 'অর্ডার আইডি';

  @override
  String get orderNow => 'এখন অর্ডার করুন';

  @override
  String get orderPlaceDes =>
      'আপনি আপনার অর্ডারের বিশদ বিবরণ সহ একটি অর্ডার নিশ্চিতকরণ/ইমেল পাবেন।';

  @override
  String get orders => 'অর্ডার';

  @override
  String get orderStatus => 'অর্ডারের অবস্থা';

  @override
  String get orderSummary => 'অর্ডার সারাংশ';

  @override
  String get other => 'অন্য';

  @override
  String get password => 'পাসওয়ার্ড';

  @override
  String get payableAmount => 'প্রদেয় পরিমান';

  @override
  String get paymentFailed => 'পেমেন্ট ব্যর্থ';

  @override
  String get paymentFailedDes =>
      'দুঃখিত, আমরা আপনার পেমেন্ট প্রক্রিয়া করতে পারি না। আবার চেষ্টা করুন।';

  @override
  String get paymentMethod => 'মূল্যপরিশোধ পদ্ধতি';

  @override
  String get paymentSuccess => 'পেমেন্ট সফল';

  @override
  String get paymentSuccessDes =>
      'আপনার পেমেন্ট সফলভাবে প্রক্রিয়া করা হয়েছে.';

  @override
  String get payNow => 'এখন পরিশোধ করুন';

  @override
  String get pending => 'বিচারাধীন';

  @override
  String get phone => 'ফোন';

  @override
  String get phoneNumber => 'ফোন নম্বর';

  @override
  String get placeOrder => 'অর্ডার প্রদান করুন';

  @override
  String get popularProducts => 'জনপ্রিয় পণ্য';

  @override
  String get postalCode => 'পোস্ট';

  @override
  String get priceHighToLow => 'মূল্য: উচ্চ থেকে কম';

  @override
  String get priceLowToHigh => 'মূল্য: কম থেকে বেশি';

  @override
  String get privacyPolicy => 'গোপনীয়তা নীতি';

  @override
  String get processig => 'প্রক্রিয়াজাতকরণ';

  @override
  String get productInCart => 'এই পণ্যটি ইতিমধ্যে আপনার কার্টে আছে!';

  @override
  String get productNotFount => 'পণ্য পাওয়া যায়নি!';

  @override
  String get productPrice => 'পণ্যের দাম';

  @override
  String get promoCode => 'এখানে প্রচার কোড লিখুন';

  @override
  String get pyment => 'পেমেন্ট';

  @override
  String get readLess => 'কম পড়ুন';

  @override
  String get readMore => 'আরও পড়ুন';

  @override
  String get recoverPassDes =>
      'আপনার পাসওয়ার্ড পুনরুদ্ধার করতে নিবন্ধন করার সময় আপনি যে ফোন নম্বর ব্যবহার করেছিলেন তা লিখুন৷ আপনি একটি কোড পাবেন।';

  @override
  String get recoverPassword => 'রিকভারি পাসওয়ার্ড';

  @override
  String get refundPolicy => 'প্রত্যর্পণ নীতি';

  @override
  String get resend => 'আবার পাঠান';

  @override
  String get resendCode => 'কোড পুনরায় পাঠান';

  @override
  String get review => 'পুনঃমূল্যায়ন';

  @override
  String get save => 'সংরক্ষণ';

  @override
  String get savedAddress => 'সংরক্ষিত ঠিকানা';

  @override
  String get searchCountryName => 'দেশের নাম অনুসন্ধান করুন';

  @override
  String get searchProduct => 'এখানে আপনার পণ্য অনুসন্ধান করুন!';

  @override
  String get select => 'নির্বাচন করুন';

  @override
  String get send => 'পাঠান';

  @override
  String get sendOtp => 'ওটিপি পাঠান';

  @override
  String get serviceItem => 'পরিষেবা আইটেম';

  @override
  String get setPassword => 'পাসওয়ার্ড সেট করুন';

  @override
  String get shoppingFrom => 'থেকে কেনাকাটা';

  @override
  String get shops => 'দোকান';

  @override
  String get shopSelectValidation =>
      'চেকআউট নিশ্চিত করার জন্য দোকান নির্বাচন করুন!';

  @override
  String get signUp => 'নিবন্ধন করুন';

  @override
  String get signUpToContinue => 'কেনাকাটা চালিয়ে যেতে সাইন আপ করুন';

  @override
  String get similarProducts => 'একই পণ্য';

  @override
  String get size => 'আপনার পণ্য আকার নির্বাচন করুন';

  @override
  String get skip => 'দেখুন';

  @override
  String get sortBy => 'ক্রমানুসার';

  @override
  String get startWriting => 'লেখা শুরু করুন ...';

  @override
  String get status => 'স্থিতি';

  @override
  String get storeVoucher => 'স্টোর ভাউচার';

  @override
  String get subject => 'বিষয়';

  @override
  String get submit => 'জমা দিন';

  @override
  String get subTotal => 'সাবটোটাল';

  @override
  String get support => 'সাপোর্ট ';

  @override
  String get termsCondistions => 'শর্তাবলী';

  @override
  String get themeMode => 'থিম মোড';

  @override
  String get toBePaid => 'পরিশোধ করুন';

  @override
  String get topSeller => 'শীর্ষ বিক্রেতা';

  @override
  String get totalAmount => 'সর্বমোট পরিমাণ';

  @override
  String get totalTaxes => 'মোট কর';

  @override
  String get typeConfirmSecretPassword =>
      'আপনার অ্যাকাউন্টের জন্য একটি গোপন নতুন পাসওয়ার্ড টাইপ করুন এবং নিশ্চিত করুন।';

  @override
  String get updatePassword => 'আপডেট পাসওয়ার্ড';

  @override
  String get updateProfile => 'আপডেট প্রোফাইল';

  @override
  String get validity => 'পর্যন্ত বৈধতা';

  @override
  String get viewMore => 'আরো দেখুন';

  @override
  String get vistiStore => 'দোকান দর্শন কর';

  @override
  String get voucherFrom => 'ভাউচার:';

  @override
  String get voucherNotAvailable => 'এই দোকানের জন্য ভাউচার পাওয়া যায় নি!';

  @override
  String get welcomeBack => 'ফিরে আসার জন্য স্বাগতম!';

  @override
  String get weSentOtp => 'আমরা আপনার ফোন নম্বরে OTP কোড পাঠিয়েছি';

  @override
  String get whoops => 'উফফফ!!';

  @override
  String get wishlist => 'ইচ্ছেতালিকা';

  @override
  String get writeSATP => 'এই পণ্য সম্পর্কে কিছু লিখুন';

  @override
  String get writeSubjectHere => 'এখানে বিষয় লিখুন';

  @override
  String get yes => 'হ্যাঁ';

  @override
  String get youAreNotLoggedIn =>
      'আপনি লগ ইন করেন নি, দয়া করে প্রথমে লগ ইন করুন।';

  @override
  String get yourCartIsEmpty => 'তোমার থলে তো খালি!';

  @override
  String get yourOrderHasBeenPlaced => 'আপনার অর্ডার দেওয়া হয়েছে!';
}
