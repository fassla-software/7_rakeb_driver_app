package com.talentindustrial.talent_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
